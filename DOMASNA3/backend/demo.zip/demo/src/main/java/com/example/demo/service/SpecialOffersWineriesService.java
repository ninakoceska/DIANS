package com.example.demo.service;

import com.example.demo.model.SpecialOffersWineries;


public interface SpecialOffersWineriesService {

    SpecialOffersWineries addOffer(SpecialOffersWineries specialOffersWineries,Long id);
}
